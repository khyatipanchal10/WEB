// Data for the "HTML Lists" Page

var fruits = [ "Apples","Oranges","Pears","Grapes","Pineapples","Mangos" ];

var directory = [
    {type: "file", name: "file1.txt"},
    {type: "file", name: "file2.txt"},
    {type: "directory", name: "HTML Files", files: [{type: "file", name: "file1.html"},{type: "file", name: "file2.html"}]},
    {type: "file", name: "file3.txt"},
    {type: "directory", name: "JavaScript Files", files: [{type: "file", name: "file1.js"},{type: "file", name: "file2.js"},{type: "file", name: "file3.js"}]}
];

window.onload = function()
{
            var c = document.querySelector("#fruit");

      var l = "<ol>"; // opening <ul>

      for(var i=0; i < fruits.length; i++)
      { // list items <li></li>
            l += "<li>" + fruits[i] + "</li>"
      }

     c.innerHTML = l += "</ol>";


function unorderedNestedList()
{
      var u = document.querySelector("#direct");
      var myUl = "<ul>";

      for(var j=0; j < directory.length; j++)
      { // list items <li></li>
            myUl += "<li>" + directory[j].name + "</li>";

            if(directory[j].files)
            {
                  myUl += "<ul>";
                  for(var k=0;k<directory[j].files.length;k++)
                  {
                        myUl += "<li>" + directory[j].files[k].name + "</li>";
                  }
                  myUl += "</ul>";
            }
      }
            myUl += "</ul>";
            u.innerHTML = myUl;
      }      

};