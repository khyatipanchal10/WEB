// Data for the "HTML Audio" Page

var audio = {
    controls: true, 
    source: [
        {src: "https://scs.senecac.on.ca/~patrick.crawford/shared/fall-2016/int222/Track03.mp3", type: "audio/mpeg"},
        {src: "https://scs.senecac.on.ca/~patrick.crawford/shared/fall-2016/int222/Track03.ogg", type: "audio/ogg"}
    ]
};

window.onload=function()
{
    var astr=document.querySelector("#aud1");
   a="";
    for(var i=0;i < audio.source.length;i++)
    {
        a+="<audio id='aud12" +i+"' controls>";
        a+= "<source src='" + audio.source[i].src + "'" + "type='" + audio.source[i].type + "'/>";
        a+="</audio><br/>";
    }
    astr.innerHTML +=a;
};