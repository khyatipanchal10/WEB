function formValidation()
{
    checkEducationStatus();
    validateLastName();
    validateFirstName();
    validatePassword();
    validateRetypePassword();
    validatePhoneNumber();
}
function validateFirstName()
{
    var charRegExp = /^[a-zA-Z '-]+$/;
    var firstName = document.querySelector("#fname").value;
    if (charRegExp.test(firstName)==false)
    {
             
        document.getElementById("fname").focus();
        document.getElementById('ferr').innerHTML="First Name must be filled out and only allow alphabet ( ' ) and ( - ).";
        return false;
    }
    else
    {
         document.getElementById("fname").focus();
        document.getElementById('ferr').innerHTML="";
        return true;
    }
}


function validateLastName() 
{
    var charRegExp = /^[a-zA-Z '-]+$/;
    var lastName = document.querySelector("#lname").value;
    if (charRegExp.test(lastName)==false)
    {
        document.getElementById("lname").focus();
        document.getElementById('lerr').innerHTML="Last Name must be filled out and only allow alphabet ( ' ) and ( - ).";
        return false;
    }
    else
    {
        document.getElementById("lname").focus();
        document.getElementById('lerr').innerHTML="";
        return true;
    }
}

function validatePhoneNumber() 
{
    var charRegExp = /^\(?([0-9]{3})\)?[-]?([0-9]{3})[-]?([0-9]{4})$/;
    var phoneNumber = document.querySelector("#phn").value;
    var temp = document.querySelector("#phn").value.substring(0, 3);
    if (charRegExp.test(phoneNumber) && phoneNumber.trim().length>=10 && temp>=100 && temp<=999 )
    {
         document.getElementById('perr').innerHTML="";
         document.getElementById("phn").focus();
        return true;      
    }
    if(phoneNumber.trim().length <10)
    {
        document.getElementById('phn').focus();
        document.getElementById('phn').value="";
        document.getElementById('perr').innerHTML ="Enter the phone number range upto 10 digit long";  
        return false;    

    }
    else
    {  
        document.getElementById('phn').value="";
        document.getElementById('phn').focus();
        document.getElementById('perr').innerHTML ="The phone number can't be all zeros or alphabets, PLEASE, enter digits only.";
        return false;  
    }
}

function checkEducationStatus()
{
	var radio_num = document.form1.graduate.length;
	var onechecked = false;
	for (var i = 0; i < radio_num; i++)
    {
	    if (document.form1.graduate[i].checked == true) 
        { // true  = checked 
		    onechecked = true;
		} // end of if
	} // End of for

	if (!onechecked)
    {
		messages = "<p>None checked</p>";
		showErrors(messages); // return false - allow for changes - form not submitted
		return false;
	}
       return true;         // return true - send out
}

function validatePassword()
{
    var pas = document.querySelector("#pass").value;
    var exp = /^[a-zA-Z0-9]+$/ ;
    if(exp.test(pas) != true || pas.length<8)
    {
        document.getElementById('passerr').innerHTML="<br />Password must contain both upper and lower case characters <br />• At least 1 number <br />• At least 8 characters long  ";
        document.getElementById("pass").focus();
        return false;  
    }
    else{
        document.getElementById('passerr').innerHTML="";
        return true;
    }
}   

function validateConfirmPassword() { 
    var conpas = document.getElementById('confirmpass').value;
    var pas = document.getElementById('pass').value;
    if(pas != conpas)
    {
        document.getElementById('conpasserr').innerHTML = "<br />Password exist doesn't match";
        document.getElementById("confirmpass").focus();
        return false;
     } 
    else
    {
        document.getElementById('conpasserr').innerHTML = "<br />Password Match";        
        return true;
    }

}


  
 
        
    
