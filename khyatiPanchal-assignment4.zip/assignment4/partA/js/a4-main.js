var filterAgeMax = Number.MAX_VALUE;
var filterType = "";

window.onload = function () {
   Pets();
}
function Pets()
{
   var result = "";
  // var filterType = "";
   var filterAgeMin = 0;
   filterAgeMax = 0;
   for (i = 0; i < petData.length; i++)
   {
         var row = '<tr> <td> <img src="' + petData[i].image.src + '" alt="'
         + petData[i].image.alt + '"height="' + petData[i].image.height + '"width="'
         + petData[i].image.width + '"></td><td><h4>' + petData[i].name + '</h4><p>' + petData[i].description + '<span><br>Age:'
         + petData[i].age + ' years old.</span></td><tr>';
      result = result.concat(row);
   }
   document.getElementById("main-table-body").innerHTML = "";
   document.getElementById("main-table-body").innerHTML += result;
}


function AllCats()
{
   var result = "";
   filterType = "cat";
   for (i = 0; i < petData.length; i++)
   {
      if (petData[i].type == filterType)
      {
            var row = '<tr> <td> <img src="' + petData[i].image.src
            + '" alt="' + petData[i].image.alt + '"height="' + petData[i].image.height
            + '"width="' + petData[i].image.width + '"></td><td><h4>' + petData[i].name + '</h4><p>'
            + petData[i].description + '<span><br>Age:' + petData[i].age + ' years old.</span></td><tr>';
            result = result.concat(row);
      }
   }
   document.getElementById("main-table-body").innerHTML = "";
   document.getElementById("main-table-body").innerHTML += result;
}

function AllDogs()
{
   var result = "";
   filterType = "dog";
   for (i = 0; i < petData.length; i++)
   {
      if (petData[i].type == filterType)
      {
         var row = '<tr> <td> <img src="' + petData[i].image.src
            + '" alt="' + petData[i].image.alt + '"height="'
            + petData[i].image.height + '"width="' + petData[i].image.width
            + '"></td><td><h4>' + petData[i].name + '</h4><p>' + petData[i].description
            + '<span><br>Age:' + petData[i].age + ' years old.</span></td><tr>';
         result = result.concat(row);
      }
   }
   document.getElementById("main-table-body").innerHTML = "";
   document.getElementById("main-table-body").innerHTML += result;
}

function AllBirds()
{
   var result = "";
  filterType = "bird";
   for (i = 0; i < petData.length; i++)
   {
      if (petData[i].type == "bird")
      {
         var row = '<tr> <td> <img src="' + petData[i].image.src
            + '" alt="' + petData[i].image.alt + '"height="'
            + petData[i].image.height + '"width="' + petData[i].image.width
            + '"></td><td><h4>' + petData[i].name + '</h4><p>' + petData[i].description + '<span><br>Age:'
            + petData[i].age + ' years old.</span></td><tr>';
         result = result.concat(row);
      }
   }
   document.getElementById("main-table-body").innerHTML = "";
   document.getElementById("main-table-body").innerHTML += result;
}

function One()
{
   var result = "";
   var filterAgeMin = 0;
   filterAgeMax = 1;
   //var filterType = "";
   for (i = 0; i < petData.length; i++)
   {
      if (petData[i].age < filterAgeMax && petData[i].type == filterType)
      {
         var row = '<tr> <td> <img src="' + petData[i].image.src + '" alt="'
            + petData[i].image.alt + '"height="' + petData[i].image.height + '"width="' + petData[i].image.width
            + '"></td><td><h4>' + petData[i].name + '</h4><p>' + petData[i].description + '<span><br>Age:' + petData[i].age
            + ' years old.</span></td><tr>';
         result = result.concat(row);
      }
      else if (petData[i].age <= filterAgeMax && filterType == "")
      {
         var row = '<tr> <td> <img src="' + petData[i].image.src + '" alt="'
            + petData[i].image.alt + '"height="' + petData[i].image.height
            + '"width="' + petData[i].image.width + '"></td><td><h4>' + petData[i].name
            + '</h4><p>' + petData[i].description + '<span><br>Age:' + petData[i].age
            + ' years old.</span></td><tr>';
         result = result.concat(row);
      }


   }
   document.getElementById("main-table-body").innerHTML = "";
   document.getElementById("main-table-body").innerHTML += result;

}



function BetweenOneAndThree()
{
   var result = "";
   var filterAgeMin = 1;
   filterAgeMax = 3;
   //var filterType = "";
   for (i = 0; i < petData.length; i++)
   {
      if (petData[i].age >= filterAgeMin && petData[i].age <= filterAgeMax && petData[i].type == filterType)
      {
         var row = '<tr> <td> <img src="' + petData[i].image.src + '" alt="' + petData[i].image.alt
            + '"height="' + petData[i].image.height + '"width="' + petData[i].image.width + '"></td><td><h4>'
            + petData[i].name + '</h4><p>' + petData[i].description + '<span><br>Age:' + petData[i].age + ' years old.</span></td><tr>';
         result = result.concat(row);
      }
      else if (petData[i].age >= filterAgeMin && petData[i].age <= filterAgeMax && filterType == "")
      {
         var row = '<tr> <td> <img src="'
            + petData[i].image.src + '" alt="' + petData[i].image.alt
            + '"height="' + petData[i].image.height + '"width="' + petData[i].image.width
            + '"></td><td><h4>' + petData[i].name + '</h4><p>' + petData[i].description + '<span><br>Age:'
            + petData[i].age + ' years old.</span></td><tr>';
         result = result.concat(row);
      }
   }
   document.getElementById("main-table-body").innerHTML = "";
   document.getElementById("main-table-body").innerHTML += result;
}

function MoreThanFour()
{
   var result = "";
   var filterAgeMin = 4;
   //var filterType = "";
   filterAgeMax = Number.MAX_VALUE;
   for (i = 0; i < petData.length; i++)
   {
      if (petData[i].age >= filterAgeMin && petData[i].age <= filterAgeMax && petData[i].type == filterType)
      {
         var row = '<tr> <td> <img src="' + petData[i].image.src + '" alt="'
            + petData[i].image.alt + '"height="' + petData[i].image.height + '"width="' + petData[i].image.width
            + '"></td><td><h4>' + petData[i].name + '</h4><p>' + petData[i].description + '<span><br>Age:' + petData[i].age + ' years old.</span></td><tr>';
         result = result.concat(row);
      }
      else if (petData[i].age >= filterAgeMin && petData[i].age <= filterAgeMax && filterType == "")
      {
         var row = '<tr> <td> <img src="' + petData[i].image.src + '" alt="' + petData[i].image.alt
            + '"height="' + petData[i].image.height + '"width="' + petData[i].image.width + '"></td><td><h4>'
            + petData[i].name + '</h4><p>' + petData[i].description + '<span><br>Age:' + petData[i].age + ' years old.</span></td><tr>';
         result = result.concat(row);
      }
   }
   document.getElementById("main-table-body").innerHTML = "";
   document.getElementById("main-table-body").innerHTML += result;
}